const express = require('express');
const mongoose = require('mongoose');
const User = require('../models/User');

const router = express.Router();

// GET /users/:id
router.get('/:id', async (req, res) => {
    const { id } = req.params;

    // Check if it's a valid MongoDB ObjectId
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).json({ error: 'Invalid user ID format' });
    }

    try {
        const user = await User.findById(id);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Only return user if age is greater than 21
        if (user.age <= 21) {
            return res.status(204).send(); // No Content
        }

        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;

