const mongoose = require('mongoose');

// Define the schema (structure) of the user document
const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    age: Number
});

// Export the model so we can use it in other files
module.exports = mongoose.model('User', userSchema);

